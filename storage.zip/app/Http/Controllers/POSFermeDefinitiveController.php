<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class POSFermeDefinitiveController extends Controller
{
    //
}
