<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PhotoRayonController extends Controller
{
    //
}
