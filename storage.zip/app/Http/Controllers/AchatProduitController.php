<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AchatProduitController extends Controller
{
    //
}
