<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClassementLivraisonController extends Controller
{
    //
}
