<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TypeProduitController extends Controller
{
    //
}
