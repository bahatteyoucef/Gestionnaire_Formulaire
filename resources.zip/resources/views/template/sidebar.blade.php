<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">
    <li class="nav-item nav-category">Formulaires</li>
    <li class="nav-item">
      <a class="nav-link" href="/">
        <i class="mdi mdi-grid-large menu-icon"></i>
        <span class="menu-title">Formulaires</span>
      </a>
    </li>
  </ul>
</nav>