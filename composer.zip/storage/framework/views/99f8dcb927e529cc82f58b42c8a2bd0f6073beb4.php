
<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('main_section'); ?>

<div class="content-wrapper">
  <div class="card">
    <div class="card-body">
      <div class="d-sm-flex justify-content-between align-items-start">
        <div>
          <h4 class="card-title card-title-dash">Questions</h4>
          <p class="card-subtitle card-subtitle-dash">50+ new questions has been added today in this form ! </p>
        </div>

        <div>
          <a href="<?php echo e(route('formulaire_questions.create',$formulaire->id_formulaire)); ?>"> <button type="button" class="btn btn-primary"> Add new Question </button> </a>
        </div>

      </div>

      <p class="card-description"></p>

      <div class="table-responsive pt-3">
        <table class="table table-bordered">

          <thead>
            <tr>
              <th class="text-center">
                #ID
              </th>

              <th class="text-center">
                Status
              </th>

              <th class="text-center">
                Groupe
              </th>

              <th class="text-center">
                Ordre
              </th>

              <th class="text-center">
                Description
              </th>

              <th class="text-center">
                Administrateur
              </th>

              <th class="text-center">
                Date de Creation
              </th>

              <th class="text-center">
                Options
              </th>

            </tr>
          </thead>

          <tbody>
            
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  

              <tr>
                <td class="text-center">
                  <?php echo e($question->id_question); ?>

                </td>

                <?php if($question->etat_question == 1): ?>
                  
                  <td class="text-center">
                    <div class="badge badge-opacity-success">Activated</div>
                  </td>

                <?php else: ?>
                  
                  <td class="text-center">
                    <div class="badge badge-opacity-warning">Disabled</div>
                  </td>

                <?php endif; ?>

                <td class="text-center">
                  <?php echo e($question->nom_groupe); ?>

                </td>

                <td class="text-center">
                  <?php echo e($question->ordre_question); ?>

                </td>

                <td class="text-center">
                  <?php echo e($question->description_question); ?>

                </td>

                <td class="text-center">
                  Ahmed Bourada
                </td>

                <td class="text-center">
                  <?php echo e($question->created_at); ?>

                </td>

                <td class="text-center">
                  <button class="btn btn-warning dropdown-toggle btn-sm" type="button" id="dropdownMenuIconButton1" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="ti-world"></i>
                  </button>

                  <div class="dropdown-menu" aria-labelledby="dropdownMenuIconButton1">
                    <?php if($question->etat_question == 0): ?>
                      <a class="dropdown-item" href="<?php echo e(route('formulaire_questions.activateDisactivate',[$formulaire->id_formulaire,$question->id_question])); ?>">Activate</a>
                    <?php endif; ?>
                    
                    <?php if($question->etat_question == 1): ?>
                      <a class="dropdown-item" href="<?php echo e(route('formulaire_questions.activateDisactivate',[$formulaire->id_formulaire,$question->id_question])); ?>">Disactivate</a>
                    <?php endif; ?>
                  </div>

                </td>

              </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>

        </table>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\Travail\Project\Coca\Projet\Laravel\resources\views/Dashboard/formulaires/questions/index.blade.php ENDPATH**/ ?>