
<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('main_section'); ?>

<div class="content-wrapper">
  <div class="card">
    <div class="card-body">
        
        <div class="" id="formulaire_form">
            <?php echo form($form); ?>

        </div>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.FormulaireVisualisation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\Travail\Project\Coca\Projet\Laravel\resources\views/Dashboard/formulaires//visualisation.blade.php ENDPATH**/ ?>