<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MarqueController extends Controller
{
    //
}
