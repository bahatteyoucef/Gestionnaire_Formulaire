<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use App\Models\Formulaire;
use App\Models\Question;
use App\Models\GroupeQuestion;
use App\Models\FormulaireGroupeQuestion;

class FormulaireGroupeController extends Controller
{
    public $url = 'Dashboard.formulaires.groupes';

    public function index()
    {
        
    }

    public function create()
    {

    }

    public function store(Request $request)
    {
        
    }

    public function show($id_formulaire)
    {
        
    }

    public function edit($id_formulaire)
    {

    }

    public function update($id_formulaire)
    {

    }

    public function destroy($id_formulaire)
    {

    }
}
