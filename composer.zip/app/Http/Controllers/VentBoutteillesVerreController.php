<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VentBoutteillesVerreController extends Controller
{
    //
}
