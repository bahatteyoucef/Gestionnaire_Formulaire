<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use App\Models\GroupeQuestion;

class GroupeQuestionController extends Controller
{
    public $url = 'Dashboard.groups.';

    public function index()
    {
        
    }

    public function create()
    {

    }

    public function store(Request $request)
    {
        
    }

    public function show($id_formulaire)
    {

    }

    public function edit($id_formulaire)
    {

    }

    public function update($id_formulaire)
    {
        
    }

    public function destroy($id_formulaire)
    {
        
    }
}
