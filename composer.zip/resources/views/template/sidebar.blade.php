<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">
    <li class="nav-item nav-category">Formulaires</li>
    <li class="nav-item">
      <a class="nav-link" href="/">
        <i class="mdi mdi-grid-large menu-icon"></i>
        <span class="menu-title">Formulaires</span>
      </a>
    </li>
    <li class="nav-item nav-category">Groupes</li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="collapse" aria-expanded="false" aria-controls="ui-basic">
        <i class="menu-icon mdi mdi-floor-plan"></i>
        <span class="menu-title">Groupes</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="groups">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item"> <a class="nav-link" href="{{url('template/pages/ui-features/buttons')}}">View List</a></li>
          <li class="nav-item"> <a class="nav-link" href="{{url('template/pages/ui-features/dropdowns')}}">Add Groupes</a></li>
        </ul>
      </div>
    </li>
    <li class="nav-item nav-category">Questions</li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="collapse" aria-expanded="false" aria-controls="ui-basic">
        <i class="menu-icon mdi mdi-floor-plan"></i>
        <span class="menu-title">Questions</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="questions">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item"> <a class="nav-link" href="{{url('template/pages/ui-features/buttons')}}">View List</a></li>
          <li class="nav-item"> <a class="nav-link" href="{{url('template/pages/ui-features/dropdowns')}}">Add Questions</a></li>
        </ul>
      </div>
    </li>
    <li class="nav-item nav-category">Utilisateurs</li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="collapse" aria-expanded="false" aria-controls="ui-basic">
        <i class="menu-icon mdi mdi-floor-plan"></i>
        <span class="menu-title">Utilisateurs</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="users">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item"> <a class="nav-link" href="{{url('template/pages/ui-features/buttons')}}">View List</a></li>
          <li class="nav-item"> <a class="nav-link" href="{{url('template/pages/ui-features/dropdowns')}}">Add User</a></li>
        </ul>
      </div>
    </li>
    
  </ul>
</nav>